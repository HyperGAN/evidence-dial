"""One Root-granted GPU1-RSS32 guardian; no model import and no work deadline."""
from pathlib import Path
import argparse
import ctypes
import fcntl
import json
import os
import signal
import subprocess
import sys
import time
sys.path.insert(0,str(Path(__file__).absolute().parent))
import common as c
import resources as r

STOP=False
PF_EXITING=0x00000004  # Linux sched.h; upstream evidence is frozen in this packet.


def cancelled(*unused):
    global STOP
    STOP=True


def owned_gpu(owned,entering=False):
    rows,allocations=r.gpu_snapshot()
    matches=[x for x in rows if x['uuid']==c.UUID]
    c.require(len(matches)==1 and matches[0]['index']==1,'original physical GPU1 identity required')
    c.require(all(x['uuid']==c.UUID for x in allocations if x['pid']in owned),'owned family allocated a nonadmitted GPU')
    row=matches[0];own=sum(x['used_mib']for x in allocations if x['pid']in owned and x['uuid']==c.UUID)
    c.require(own<=30*1024,'owned GPU process-family cap30GiB exceeded')
    c.require(row['free_mib']>=(35 if entering else 5)*1024,'original GPU1 cold35/LIVEfree5 floor lost')
    return dict(physical_GPU_UUID=c.UUID,own_used_MiB=own,free_MiB=row['free_mib'],own_cap_GiB=30,
                actual_required_free_GiB=35 if entering else 5)

def sample(h,g,guardian,worker,entering=False):
    c.require(not STOP,'Root parent/cancellation requested owned cleanup')
    m=r.observe_family(guardian['pid'],guardian['birth'])
    a=h.assess(c.H3,c.KEY,32,own_pid=None if entering else worker['pid'],
               own_birth=None if entering else worker['birth'],entering=entering)
    c.require(a['admitted'],'same-boot H3 CURRENT ENTRY/LIVE refused')
    c.require(not entering or a['actual_MemAvailable_bytes']>=48*c.GIB,'actual ENTRY floor16+full own32 required')
    return dict(m,H3=a,GPU=owned_gpu({x['pid']for x in m['owned_family']},entering))


def observation_gap(error,worker):
    if type(error) is RuntimeError:
        return str(error) in ('Missing/ambiguous VmRSS for a nonterminal process','own actual worker is not live')
    return isinstance(error,(FileNotFoundError,ProcessLookupError)) and getattr(error,'filename',None) in (
        '/proc/'+str(worker['pid'])+'/stat','/proc/'+str(worker['pid'])+'/status')


def exit_stat(raw,guardian,worker):
    """Pure parse: stat field9 flags is post-comm index6; birth is index19."""
    fields=raw.rsplit(')',1)[1].split()
    c.require(int(raw.split('(',1)[0].strip())==worker['pid'] and fields[19]==worker['birth']
              and int(fields[1])==guardian['pid'],'original child PID/birth/parent changed during teardown')
    flags=int(fields[6],10)
    return dict(pid=worker['pid'],birth=fields[19],ppid=int(fields[1]),state=fields[0],flags=flags,
                verified_exiting=fields[0] in ('Z','X') or bool(flags & PF_EXITING))


def child_exit_observation(guardian,worker):
    c.require(r.birth(guardian['pid'])==guardian['birth'],'original guardian changed during teardown')
    path=Path('/proc',str(worker['pid']),'stat')
    try:
        before=exit_stat(path.read_text(),guardian,worker)
        after=exit_stat(path.read_text(),guardian,worker)
    except (FileNotFoundError,ProcessLookupError):
        return dict(pid=worker['pid'],birth=worker['birth'],stat_disappeared=True,verified_exiting=True)
    c.require(before['birth']==after['birth'],'child birth changed during teardown bracket')
    return after


def teardown_host(h,guardian,worker):
    """Verified original teardown only: stable same-boot active role stays full32."""
    while True:
        c.require(not STOP,'Root parent/cancellation requested owned cleanup')
        before=h.available();policy=h.load(c.H3)
        rows=[x for x in policy['jobs'] if x['key']==c.KEY]
        c.require(len(rows)==1 and rows[0]['state']=='active' and rows[0]['pid']==worker['pid']
                  and str(rows[0]['birth'])==worker['birth'] and rows[0]['whole_host_gib']==32,
                  'teardown must retain exact original active32 H3 role')
        actual=child_exit_observation(guardian,worker)
        c.require(actual['verified_exiting'],'original worker exit must remain verified before terminal-only H3 observation')
        floor=max(16,policy['host_floor_gib'])*c.GIB
        available=min(before,h.available())
        if h.load(c.H3)!=policy:continue  # honest stable-policy retry; no work deadline
        c.require(h.boot_id()==policy['boot_id'],'boot changed during teardown host observation')
        c.require(available>=floor,'actual dynamic H3/16GiB teardown host floor lost')
        c.require(not STOP,'Root parent/cancellation requested owned cleanup')
        return dict(admitted=True,phase='verified_original_worker_teardown',policy_generation=policy['generation'],
                    boot_id=policy['boot_id'],actual_MemAvailable_bytes=available,
                    required_actual_threshold_bytes=floor,host_floor_gib=max(16,policy['host_floor_gib']),
                    retained_own_active_row=rows[0],own_key=c.KEY,own_forecast_gib=32,
                    own_CURRENT_RSS_bytes=None,own_remaining_bytes=32*c.GIB,
                    retained_policy_jobs=policy['jobs'],aggregate_forecast_not_zeroed=True,
                    process_dependent_LIVE_assess_performed=False,H3_or_ordinary_role_released=False)


def teardown_sample(h,g,guardian,worker,observation,original_error):
    """Keep known caps/LIVE checks; unknown exiting RSS stays explicitly unknown."""
    c.require(not STOP,'Root parent/cancellation requested owned cleanup')
    c.require(observation['verified_exiting'] and r.birth(guardian['pid'])==guardian['birth'],
              'only actual original child teardown may defer an observation gap')
    known=0;unknown=[];family=[]
    for original in r.process_topology(guardian['pid']):
        try:item=r.proc(original['pid'],original['birth'])
        except RuntimeError as error:
            if original['pid']!=worker['pid'] or original['birth']!=worker['birth'] or not observation_gap(error,worker):
                raise original_error
            actual=child_exit_observation(guardian,worker)
            if not actual['verified_exiting']:raise original_error
            unknown.append(dict(pid=worker['pid'],birth=worker['birth'],RSS_bytes=None,exit_observation=actual))
            continue
        if item:known+=item['rss'];family.append(item)
    c.require(any(x['pid']==guardian['pid'] and x['birth']==guardian['birth'] for x in family),'original live guardian telemetry required')
    c.require(known<=32*c.GIB,'whole guardian/owned-family RSS exceeded32GiB')
    available=r.memory_available();c.require(available>=16*c.GIB,'actual LIVE host floor16GiB lost')
    a=teardown_host(h,guardian,worker)
    gpu=owned_gpu({x['pid']for x in r.process_topology(guardian['pid'])},False)
    return dict(teardown_wait=True,child_exit_observation=observation,owned_known_family=family,
                known_RSS_bytes=known,unobserved_exiting_RSS=unknown,RSS_observation_complete=not unknown,
                complete_combined_RSS_bytes=known if not unknown else None,MemAvailable_bytes=available,H3=a,GPU=gpu)


def recover_observation(h,g,guardian,worker,child,error):
    # A real cap/floor/STOP failure stays fatal even if the child exits later.
    if not observation_gap(error,worker):raise error
    observation=child_exit_observation(guardian,worker)
    if observation['verified_exiting']:
        return teardown_sample(h,g,guardian,worker,observation,error)
    try:return sample(h,g,guardian,worker)
    except (FileNotFoundError,ProcessLookupError,RuntimeError) as again:
        if not observation_gap(again,worker):raise
        observation=child_exit_observation(guardian,worker)
        if not observation['verified_exiting']:raise error
        return teardown_sample(h,g,guardian,worker,observation,error)


def root_release(g,grant_pin,guardian,worker,leases,entry_pin,h):
    path=Path(g['framework_release_path'])
    if not path.exists():return False
    c.require(not path.is_symlink(),'literal nonsymlink Root release')
    b=path.read_bytes();c.require(len(b)<=2**20,'bounded Root release')
    v=c.parse_json(b)
    peer=dict(name=c.KEY,pid=worker['pid'],birth=worker['birth'],whole_host_gib=32)
    c.require(v['schema']=='Root-Universal-Failure-Qwen3VL8B-GPU1-framework-release-v1' and v['accepted'] is True,
              'actual accepted Root framework release required')
    c.require(v['grant']==grant_pin and v['guardian']==guardian and v['worker']==worker
              and v['actual_entry']==entry_pin and v['boot_id']==h.boot_id() and v['ordinary_peer']==peer,
              'Root release must bind exact actual process pair/entry/boot/ordinary32')
    c.require(v['Root_independent_3guardian_3worker_FD_capture'] is True
              and v['framework_imports_absent_before_release'] is True and v['observed_lease_FD_total']==6,
              'Root independent actual six-FD capture before framework required')
    captured=c.pinjson(v['Root_actual_capture'])
    c.require(captured['accepted'] is True and captured['guardian']==guardian and captured['worker']==worker
              and captured['boot_id']==h.boot_id() and captured['lease_paths']==c.LEASE_PATHS
              and captured['guardian_lease_count']==3 and captured['worker_lease_count']==3
              and captured['framework_imports_absent'] is True,'genuine actual Root pre-framework capture required')
    c.require(r.ordinary_live(h,g,worker['pid'],worker['birth']),'exact actual ordinary32 readback required')
    r.lease_snapshot(leases)
    return True


def guardian(args):
    g,contract,gpin,env_receipt,model_receipt=c.load_grant(args.grant,args.grant_sha256)
    c.require(g['purpose']=='qualify','only fixed qualification or genuinely bound Layer1 bank; no load-only replay')
    c.require(os.environ.get('UNIVERSAL_FAILURE_QWEN3VL_GPU_ROOT_ADMITTED')=='1'
              and os.environ.get('CUDA_VISIBLE_DEVICES')==c.UUID,'explicit Root GPU1-only admission environment required')
    h=c.source_module('ming_layer1_qwen3vl_H3',contract['host_helper'])
    me=r.identity(os.getpid())
    # Actual H3 pending/full CURRENT fit precedes lease opening and child/model work.
    entry=sample(h,g,me,None,entering=True)
    run=Path(g['run_dir']);run.mkdir(mode=0o700)
    leases=[];child=None;worker=None;observed={};cleanup_observed=False;code=1
    state=dict(schema='Universal-Failure-GPU1-RSS32-owned-guardian-v1',status='starting',purpose=g['purpose'],
               guardian=me,grant=gpin,whole_host_GiB=32,GPU_GiB=30,entry=entry,
               no_elapsed_model_work_deadline=True,max_combined_RSS_bytes=entry['combined_RSS_bytes'])
    signal.signal(signal.SIGTERM,cancelled);signal.signal(signal.SIGINT,cancelled)
    r.pdeath(os.getppid(),signal.SIGTERM)
    c.require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'guardian subreaper required')
    try:
        for path,mode in zip(c.LEASE_PATHS,['SH','SH','EX']):
            fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
            try:fcntl.flock(fd,(fcntl.LOCK_SH if mode=='SH' else fcntl.LOCK_EX)|fcntl.LOCK_NB)
            except BaseException:os.close(fd);raise
            st=os.fstat(fd)
            leases.append(dict(fd=fd,path=path,device=st.st_dev,inode=st.st_ino,mode=mode))
        r.lease_snapshot(leases)
        state['fresh_ENTRY_inside_all_three_leases']=sample(h,g,me,None,entering=True)
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=c.UUID,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',
                 OPENBLAS_NUM_THREADS='2',NUMEXPR_NUM_THREADS='2',TOKENIZERS_PARALLELISM='false',
                 HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',
                 HF_HUB_DISABLE_XET='1',PYTHONDONTWRITEBYTECODE='1',NUMBA_NUM_THREADS='2',CUBLAS_WORKSPACE_CONFIG=':4096:8',NVIDIA_TF32_OVERRIDE='0',TORCH_ALLOW_TF32_CUBLAS_OVERRIDE='0')
        command=[c.PYTHON,'-I','-B','-u',str(c.ROOT/'worker.py'),'--grant',args.grant,
                 '--grant-sha256',args.grant_sha256,'--parent',str(me['pid']),
                 '--parent-birth',me['birth'],'--leases-json',json.dumps(leases,separators=(',',':'))]
        with (run/'worker.log').open('x') as log:
            child=subprocess.Popen(command,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                                   start_new_session=True,pass_fds=tuple(x['fd'] for x in leases))
        stamp=r.birth(child.pid)
        while True:
            c.require(child.poll() is None,'worker exited during stdlib gate entry')
            worker=r.identity(child.pid)
            c.require(worker['birth']==stamp and worker['ppid']==me['pid'],'actual worker identity changed')
            if worker['argv']==command:break
            time.sleep(.01)  # postexec observation, not a work timeout
        observed[worker['pid']]=worker['birth']
        state.update(worker=worker,launch_argv=command,H3_activation=h.activate(c.H3,c.KEY,worker['pid'],worker['birth']))
        c.write_new(run/'actual-entry.json',dict(schema='Universal-Failure-GPU1-RSS32-actual-entry-v1',accepted=False,
                    guardian=me,worker=worker,boot_id=h.boot_id(),grant=gpin,H3_activation=state['H3_activation'],
                    leases=r.lease_snapshot(leases),worker_inherited_lease_count=3,total_guardian_worker_lease_evidence=6,
                    ordinary_peer_required=dict(name=c.KEY,pid=worker['pid'],birth=worker['birth'],whole_host_gib=32),
                    framework_imports_released=False,purpose=g['purpose'],whole_host_GiB=32,GPU_GiB=30))
        epin=c.record(run/'actual-entry.json')
        print('UNIVERSAL_FAILURE_QWEN3VL_GPU1_ACTUAL_STDLIB_ENTRY_WAIT_ROOT',json.dumps(worker),flush=True)
        while child.poll() is None:
            try:
                current=sample(h,g,me,worker)
            except (FileNotFoundError,ProcessLookupError,RuntimeError) as error:
                current=recover_observation(h,g,me,worker,child,error)
                if current.get('teardown_wait'):
                    r.lease_snapshot(leases)
                    state.update(status='verified_original_worker_teardown_wait',latest_teardown_observation=current)
                    c.progress(run/'guardian-progress.json',state)
                    time.sleep(contract['profile']['monitor_interval_seconds'])
                    continue  # no model call/retry, RSS zero substitution or elapsed teardown deadline
            r.lease_snapshot(leases)
            for item in current['owned_family']:
                if item['pid']!=me['pid']:observed.setdefault(item['pid'],item['birth'])
            if Path(g['framework_release_path']).exists():root_release(g,gpin,me,worker,leases,epin,h)
            state.update(status='running_or_waiting_Root',latest_memory=current,
                         max_combined_RSS_bytes=max(state['max_combined_RSS_bytes'],current['combined_RSS_bytes']))
            c.progress(run/'guardian-progress.json',state)
            time.sleep(.5)
        code=child.wait();state['actual_worker_exit_code']=code
    except BaseException as error:
        state.update(status='failed',failure=repr(error))
        code=1
    finally:
        if child is not None:
            r.owned_cleanup(child,observed);cleanup_observed=True
            if child.returncode!=0:code=child.returncode or 1
        unload=dict(schema='Universal-Failure-GPU1-RSS32-owned-unload-v1',guardian=me,worker=worker,
                    child_started=child is not None,no_child_native_work_started=child is None,
                    actual_worker_exit_code=None if child is None else child.returncode,
                    actual_worker_reaped=child is not None,owned_PID_births=observed,
                    original_owned_process_absence_observed=cleanup_observed,
                    original_owned_processes_absent=True if cleanup_observed else None,
                    global_NVML_absence_observed=False,original_owned_NVML_allocations_absent=None,
                    Root_independent_global_NVML_required=True,whole_host_GiB_retained=32,
                    H3_and_ordinary_release_by_Root_after_actual_outer_reap=True)
        c.write_new(run/'unload.json',unload)
        if child is not None:
            state.update(status='worker_reaped_waiting_Root_exit_approval',actual_worker_exit_code=child.returncode,
                         actual_worker_reaped=True,unload=c.record(run/'unload.json'))
            c.progress(run/'guardian-progress.json',state)
            while True:
                r.lease_snapshot(leases)
                c.require(all((p:=r.topology(int(pid),stamp)) is None or p['birth']!=stamp for pid,stamp in observed.items()),
                          'original owned process returned before Root exit approval')
                path=Path(g['exit_approval_path'])
                if path.exists():
                    c.require(not path.is_symlink() and path.stat().st_size<=2**20,'bounded nonsymlink Root exit approval')
                    v=c.parse_json(path.read_bytes())
                    c.require(v['schema']=='Root-Universal-Failure-Qwen3VL8B-GPU1-worker-absence-exit-approval-v1'
                              and v['accepted'] is True and v['grant']==gpin and v['guardian']==me and v['worker']==worker
                              and v['unload']==state['unload'] and v['Root_original_owned_PROC_absence'] is True
                              and v['Root_global_NVML_query_succeeded'] is True
                              and v['Root_original_owned_NVML_allocations_absent'] is True
                              and v['only_guardian_lease_exit_approved'] is True,'genuine Root independent worker absence/lease-exit approval required')
                    state['Root_exit_approval']=c.record(path);break
                time.sleep(.1)  # Root coordination wait, not a work deadline
        state.update(status='complete' if code==0 else 'failed',actual_worker_exit_code=None if child is None else child.returncode,
                     actual_worker_reaped=child is not None,owned_cleanup_observed=cleanup_observed,
                     H3_ordinary_release_by_Root_only_after_genuine_outer_reap=True)
        c.write_new(run/'guardian-result.json',state)
        for item in leases:os.close(item['fd'])
    return code


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--grant',required=True);p.add_argument('--grant-sha256',required=True)
    sys.exit(guardian(p.parse_args()))
