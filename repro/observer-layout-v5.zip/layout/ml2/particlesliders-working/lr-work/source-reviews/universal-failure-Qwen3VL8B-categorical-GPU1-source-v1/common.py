"""Pure stdlib metadata and durable I/O; import performs no runtime observation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

ROOT = Path(__file__).absolute().parent
KEY = 'Universal-Failure-Qwen3VL8B-GPU1'
H3 = '/ml2/particlesliders-working/sampler-studio/host-resource-policy-v2.json'
ORDINARY = '/ml2/particlesliders-working/sampler-studio/admission-policy.json'
PYTHON = '/ml2/particlesliders-working/lr-work/output-effect-scoring/ming-layer1-qwen3vl8b-cuda-env-v1/bin/python'
MODEL_CACHE = '/mnt/nvme/qualification/metrics/qwen3-vl-8b-0c351dd0'
ACTUAL = '/ml2/particlesliders-working/lr-work/universal-failure/qwen3vl8b-categorical-first-qualification-v1'
BANK = '/ml2/particlesliders-working/lr-work/output-effect-scoring/ming-layer1-qwen3vl8b-fourcase-actual-v1'
UUID = 'GPU-cb4ce47d-d968-bffd-5646-e830a9fa1c69'
LEASE_PATHS = ['/mnt/nvme/sliders/qualification/admission-gpu-1.lock',
               '/mnt/nvme/sliders/locks/gpu-1.lock',
               '/ml2/particlesliders-working/sampler-studio/state/universal-failure-qwen3vl8b-gpu1.lock']
GIB = 2**30


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while block := f.read(8 * 2**20):
            h.update(block)
    return h.hexdigest()


def pairs_no_duplicates(items):
    value = {}
    for key, item in items:
        require(key not in value, 'duplicate JSON key')
        value[key] = item
    return value


def parse_json(raw):
    def no_constant(value):
        raise RuntimeError('nonfinite JSON constant: ' + value)
    return json.loads(raw, object_pairs_hook=pairs_no_duplicates, parse_constant=no_constant)


def pinned(pin):
    p = Path(pin['path'])
    require(p.is_absolute() and '..' not in p.parts and not p.is_symlink(), 'literal nonsymlink file required')
    b = p.read_bytes()
    require(len(b) == pin['bytes'] and hashlib.sha256(b).hexdigest() == pin['sha256'], 'exact file record differs')
    return b


def pinjson(pin):
    return parse_json(pinned(pin))


def record(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))


def write_new(path, value):
    path = Path(path)
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    fd=os.open(str(path.parent),os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def progress(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp-' + str(os.getpid()))
    write_new(temporary, value)
    os.replace(temporary, path)


def source_module(name, pin):
    raw = pinned(pin)
    spec = importlib.util.spec_from_file_location(name, pin['path'])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, pin['path'], 'exec'), module.__dict__)
    return module


def validate_grant_metadata(g, contract, source_map, contract_pin, map_pin):
    require(g.get('schema') == 'Root-Universal-Failure-Qwen3VL8B-GPU1-one-entry-v1' and g.get('accepted') is True,
            'genuine accepted Root ONE entry required; Source is not authority')
    require(g['actual_sole_owner_poller']=='/root' and g['automatic_retry'] is False,'Root sole owner; no retry/successor')
    require(g['purpose']=='qualify' and type(g['whole_host_GiB']) is int and g['whole_host_GiB']==32
            and type(g['RSS_GiB']) is int and g['RSS_GiB']==32,'fixed original GPU1-RSS32 profile')
    require(g['source_contract']==contract_pin and g['source_map']==map_pin,'exact Source contract/map')
    require(g['host_key']==KEY and g['ordinary_peer_name']==KEY and g['h3_policy']==H3
            and g['ordinary_policy']==ORDINARY,'actual exact host/ordinary role')
    require(g['python']==PYTHON and g['lease_paths']==LEASE_PATHS and g['lease_modes']==['SH','SH','EX'],'fixed new CUDA interpreter/threeGPU leases')
    require(type(g['GPU_GiB']) is int and g['GPU_GiB']==30 and g['CUDA_VISIBLE_DEVICES']==UUID and g['EMA'] is None,'fixed actualGPU1/no EMA')
    require(g['instrument_contract']==contract['instrument_contract'] and g['wheel_lock']==contract['wheel_lock'],'frozen visual instrument/wheels')
    require(g['model_cache']==MODEL_CACHE==contract['model_cache'],'same pinned model')
    run=Path(g['run_dir'])
    require(str(run)==(ACTUAL if g['purpose']=='qualify' else BANK),'one fixed exclusive path per purpose; no replay')
    if g['purpose']=='qualify':
        require(g['image_call_limit']==7 and g['bank_input_authority'] is None and g['meaning_result'] is None
                and g['LR_scoring_authorized'] is False,'exact two references only; no bank')
    require(g['framework_release_path']==str(run/'root-framework-release-v1.json')
            and g['exit_approval_path']==str(run/'root-worker-absence-exit-approval-v1.json'),'fixed Root handshake paths')
    require(source_map['schema']=='Universal-Failure-Qwen3VL8B-finite-Source-map-v1'
            and len(source_map['records'])==len({x['path'] for x in source_map['records']}),'finite unique Source records')


def load_grant(path, sha):
    p = Path(path)
    require(p.is_absolute() and '..' not in p.parts and not p.is_symlink(), 'literal Root grant path required')
    b = p.read_bytes()
    require(len(b) <= 2**20 and hashlib.sha256(b).hexdigest() == sha, 'bounded exact Root grant required')
    g = parse_json(b)
    # Refuse draft/unbound metadata before any process, resource, lock or model access.
    require(g.get('accepted') is True, 'Source-only/draft grant has no actual authority')
    cp, mp = record(ROOT/'execution-contract-v1.json'), record(ROOT/'required-source-map-v1.json')
    contract, inventory = pinjson(cp), pinjson(mp)
    validate_grant_metadata(g, contract, inventory, cp, mp)
    for pin in inventory['records']:
        pinned(pin)
    adoption = pinjson(g['source_adoption'])
    require(adoption['schema'] == 'Root-Universal-Failure-Qwen3VL8B-GPU1-Source-adoption-v1'
            and adoption['accepted'] is True and adoption['source_files'] == inventory['records']
            and adoption['source_contract'] == cp and adoption['source_map'] == mp,
            'exact Root finite Source adoption required')
    require(Path(sys.executable).absolute() == Path(PYTHON) and sys.version_info[:3] == (3,12,15),
            'exact private CPython3.12.15 interpreter required')
    env = pinjson(g['environment_receipt'])
    lock = pinjson(contract['wheel_lock'])
    versions = {x['project']:x['version'] for x in lock['packages']}
    require(env['schema'] == 'Root-Ming-Layer1-Qwen3VL8B-CUDA-environment-v1' and env['accepted'] is True
            and env['wheel_lock'] == contract['wheel_lock'] and env['versions'] == versions
            and env['pip_check_exit_code'] == 0 and env['all_exact_wheel_SHA256_verified'] is True,
            'Root exact complete wheel installation receipt required')
    require(env['python']['path'] == PYTHON and record(PYTHON) == env['python'] and env['python']['bytes'] == contract['base_interpreter']['bytes'] and env['python']['sha256'] == contract['base_interpreter']['sha256'], 'exact installed original CPython interpreter record required')
    installed = {x['project']:x for x in env['wheels']}
    require(len(env['wheels']) == len(versions) and set(installed) == set(versions), 'one installed record for every locked wheel required')
    for item in lock['packages']:
        row=installed[item['project']]
        require(row['version']==item['version'] and type(row['sha256'])is str and len(row['sha256'])==64 and type(row['filename'])is str,'Root whole-wheel SHA/filename/version record required')
        if 'reuse_exact_original_locked_wheel' in item:
            old=item['reuse_exact_original_locked_wheel']
            require(row['filename']==old['wheel']['filename'] and row['sha256']==old['wheel_sha256'],'Exact original44 non-CUDA wheel reuse required')
    receipt = pinjson(g['model_download_receipt'])
    require(receipt['schema'] == 'Root-Qwen3VL8B-pinned-model-download-v1' and receipt['accepted'] is True
            and receipt['model_id'] == contract['model_id'] and receipt['revision'] == contract['model_revision']
            and receipt['allowlist'] == contract['model_allowlist'], 'exact Root pinned model download receipt required')
    return g, contract, dict(path=str(p), bytes=len(b), sha256=sha), env, receipt
