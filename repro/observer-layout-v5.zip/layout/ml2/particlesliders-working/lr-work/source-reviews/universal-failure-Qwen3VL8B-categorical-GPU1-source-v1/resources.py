"""Stdlib GPU1 process-family telemetry. No observation or action at import."""
from pathlib import Path
import ctypes
import fcntl
import json
import os
import signal
import time
import subprocess

GIB=2**30


def require(value, message):
    if not value:
        raise RuntimeError(message)


def birth(pid):
    return Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()[19]


def identity(pid):
    stat = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=pid, birth=stat[19], ppid=int(stat[1]), argv=[os.fsdecode(x) for x in Path('/proc', str(pid), 'cmdline').read_bytes().split(b'\0') if x])


def rss_from_status(status, state):
    values = [int(x.split()[1]) * 1024 for x in status.splitlines() if x.startswith('VmRSS:')]
    if len(values) == 1:
        return values[0]
    raise RuntimeError('Missing/ambiguous VmRSS for a nonterminal process')


def topology(pid, expected_birth=None):
    """Identity/topology only; never read a foreign process's status or RSS."""
    p=Path('/proc',str(pid))
    try:
        before=(p/'stat').read_text().rsplit(')',1)[1].split()
        if expected_birth is not None and before[19]!=expected_birth:return None
        uid=p.stat().st_uid
        after=(p/'stat').read_text().rsplit(')',1)[1].split()
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        return None
    if before[19]!=after[19] or uid!=os.getuid():return None
    if expected_birth is not None and after[19]!=expected_birth:return None
    return dict(pid=pid,ppid=int(after[1]),pgrp=int(after[2]),sid=int(after[3]),
                birth=after[19],state=after[0])


def proc(pid, expected_birth=None):
    """Strict RSS for an already-owned process; no live missing-RSS zero."""
    p=Path('/proc',str(pid))
    try:
        before=(p/'stat').read_text().rsplit(')',1)[1].split()
        if expected_birth is not None and before[19]!=expected_birth:return None
        status=(p/'status').read_text()
        after=(p/'stat').read_text().rsplit(')',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):
        return None
    if expected_birth is not None and after[19]!=expected_birth:return None
    require(before[19]==after[19], 'process birth changed during status bracket')
    uid=[x for x in status.splitlines() if x.startswith('Uid:')]
    require(len(uid)==1, 'unambiguous process UID required')
    if int(uid[0].split()[1])!=os.getuid():return None
    state=after[0]
    try:
        rss=rss_from_status(status,state)
    except RuntimeError:
        # Resolve only an actual exit/reuse race; a still-live owned process
        # with unknown/ambiguous RSS remains an error and triggers cleanup.
        try:final=(p/'stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError):return None
        if expected_birth is not None and final[19]!=expected_birth:return None
        require(final[19]==after[19], 'process birth changed during final RSS observation')
        state=final[0]
        rss=rss_from_status(status,state)
    return dict(pid=pid,ppid=int(after[1]),pgrp=int(after[2]),sid=int(after[3]),birth=after[19],
                rss=rss,state=state)


def memory_available():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1])*1024
    raise RuntimeError('Host memory telemetry is unavailable')


def owned_topology(processes, root_pid):
    owned = {root_pid} | {p['pid'] for p in processes if p['pgrp']==root_pid or p['sid']==root_pid}
    while True:
        previous = len(owned)
        owned.update(p['pid'] for p in processes if p['ppid'] in owned)
        if len(owned) == previous: break
    return [p for p in processes if p['pid'] in owned]


def process_topology(root_pid):
    processes=[]
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            item=topology(int(p.name))
            if item:processes.append(item)
    return owned_topology(processes,root_pid)


def process_family(root_pid):
    result=[]
    for original in process_topology(root_pid):
        item=proc(original['pid'],original['birth'])
        if item:result.append(item)
    return result


def pdeath(parent, sig):
    require(ctypes.CDLL(None, use_errno=True).prctl(1, sig, 0, 0, 0) == 0,
            'parent-death binding failed')
    require(os.getppid() == parent, 'parent changed during PDEATH binding')


def lease_snapshot(items):
    require(len(items)==3 and len({x['fd'] for x in items})==3, 'exactly three open GPU lease descriptions')
    result=[]
    for item in items:
        fd=item['fd']; path=Path(item['path'])
        a,b=os.fstat(fd),os.stat(path,follow_symlinks=False)
        require((a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)==(item['device'],item['inode']), 'lease inode changed')
        locks=[x for x in Path('/proc/self/fdinfo',str(fd)).read_text().splitlines() if 'FLOCK' in x]
        require(len(locks)==1 and (' READ ' if item['mode']=='SH' else ' WRITE ') in locks[0], 'real GPU lease FLOCK mode absent')
        result.append(dict(item,kernel_FLOCK=locks[0]))
    return result


def ordinary_live(h, grant, pid, stamp):
    value = json.loads(Path(grant['ordinary_policy']).read_bytes())
    require(value['boot_id'] == h.boot_id(), 'same-boot ordinary policy required')
    if value['entry_hold'] is not False:
        return False
    rows = [x for x in value['peers'] if x['name'] == grant['ordinary_peer_name']]
    if not rows:
        return False
    require(len(rows) == 1 and type(rows[0]['pid']) is int and rows[0]['pid'] == pid and
            type(rows[0]['birth']) is str and rows[0]['birth'] == stamp and
            rows[0]['whole_host_gib'] == 32, 'exact actual worker ordinary32 peer required')
    return True


def observe_family(guardian, stamp):
    require(birth(guardian)==stamp, 'original guardian birth required')
    family=process_family(guardian)
    require(any(x['pid']==guardian and x['birth']==stamp for x in family), 'original guardian absent')
    rss=sum(x['rss'] for x in family)
    available=memory_available()
    require(available>=16*GIB, 'actual LIVE host floor16GiB lost')
    require(rss<=32*GIB, 'whole guardian/owned-family RSS exceeded32GiB')
    return dict(owned_family=family,combined_RSS_bytes=rss,MemAvailable_bytes=available)


def owned_cleanup(child, observed):
    """Stable live guardian/subreaper; individual signals recheck PID+birth."""
    started=time.monotonic()
    while True:
        for p in process_topology(os.getpid()):
            if p['pid']!=os.getpid():observed.setdefault(p['pid'],p['birth'])
        child.poll()
        while True:
            try:
                pid,unused=os.waitpid(-1,os.WNOHANG)
                if not pid:break
                if pid==child.pid and child.returncode is None:
                    child.returncode=os.waitstatus_to_exitcode(unused)
            except ChildProcessError:break
        live=[]
        for pid,stamp in observed.items():
            item=topology(pid,stamp)
            if item and item['birth']==stamp:live.append(item)
        if not live:
            if child.returncode is None:child.wait()
            return
        sig=signal.SIGTERM if time.monotonic()-started<15 else signal.SIGKILL
        for item in live:
            now=topology(item['pid'],item['birth'])
            if now and now['birth']==item['birth']:
                try:os.kill(item['pid'],sig)
                except ProcessLookupError:pass
        time.sleep(.1)  # cleanup grace only, never a model-work deadline


def gpu_snapshot():
    result = subprocess.run(['nvidia-smi','--query-gpu=index,uuid,memory.total,memory.free','--format=csv,noheader,nounits'],
                            check=True, capture_output=True, text=True, timeout=5)
    rows = []
    for line in result.stdout.splitlines():
        index, identity, total, free = [x.strip() for x in line.split(',')]
        rows.append({'index':int(index),'uuid':identity,'total_mib':int(total),'free_mib':int(free)})
    result = subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],
                            check=True, capture_output=True, text=True, timeout=5)
    allocations = []
    for line in result.stdout.splitlines():
        if not line.strip(): continue
        pid, identity, used = [x.strip() for x in line.split(',')]
        allocations.append({'pid':int(pid),'uuid':identity,'used_mib':int(used)})
    return rows, allocations
